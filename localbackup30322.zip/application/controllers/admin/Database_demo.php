<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Database_demo extends CI_Controller {
    private $data;
    private $page;
    /**
    @param void
    @return void
    */
    function __construct(){
        parent::__construct();
        if(!$this->session->userdata('admin_id')){
            redirect(base_url('admin/signin'));
        }
       
        $this->load->library('excel');
        $this->load->model('admin/Admin_Model','admin');
        $this->load->model('admin/User_Model','usermodel');
        $response = $this->admin->edit($this->session->userdata('admin_id'));
        $this->load->model('admin/Category_Model','category');
        $this->load->model('admin/Exal_Model','exal');
        $this->load->model('admin/Database_demo_model','dbdemomodel');
        $settings =$this->load->model('admin/Settings_Model','settings');
       $settings = $this->load->model('admin/RolePermission_Model','rolepermission');
       $this->data['settings'] = $this->settings->get();
        if($response['status']===true){
             $this->data['admin'] = $response['record'];
            $this->data['userrole']= $this->rolepermission->edit($this->data['admin']['role']);
            $this->page = 'exal';
            chkaccess($this->data,$this->page,'view');
        }
        else{
            redirect(base_url('admin/signin'));
        }
    }

    /**
    @param void
    @return void
    */
    public function index(){
        chkaccess($this->data,$this->page,'view');
        $this->data['demodb'] = $this->dbdemomodel->get();
        $this->load->view('admin/databaseDemo/list',$this->data);
    }
    
    public function create(){
        chkaccess($this->data,$this->page,'create');
        $this->data['user'] = $this->usermodel->getUserRoleWise(3);
        $this->data['exal'] = $this->exal->get();
        $this->load->view('admin/databaseDemo/form',$this->data);
    }

    /**
    @param void
    @return void
    */
    public function store(){
        chkaccess($this->data,$this->page,'create');
        $validation = [
            ['field' => 'user_id','label' => 'User','rules' => 'trim|required|xss_clean|is_natural_no_zero'],
            ['field' => 'exal_id','label' => 'Exal','rules' => 'trim|required|xss_clean|is_natural_no_zero'],
            ['field' => 'show_no_of_data','label' => 'Show no of data','rules' => 'trim|required|xss_clean|is_natural_no_zero'],
            ['field' => 'link_expire_duration','label' => 'Expiry duration','rules' => 'trim|required|xss_clean'],
            ['field' => 'otp_type','label' => 'Otp type','rules' => 'trim|required|xss_clean'],
            ];
        $this->form_validation->set_rules($validation);
        if($this->form_validation->run() == false){
            $this->load->view('admin/databaseDemo/form',$this->data);
        }else{
            $storedata = $_POST;
            $storedata['demourl'] = $this->keygen();
            $storedata['link_expire_duration'] = strtotime($_POST['link_expire_duration']);
           
            $this->dbdemomodel->store($storedata);
            $lastdbdemoid=$this->db->insert_id();
            if($this->db->affected_rows() > 0){
                 $this->session->set_flashdata('success', 'Demo database created successfully');
            }
            else{
                 $this->session->set_flashdata('error', 'Somthing is wrong');
            
            } 
            redirect(base_url('admin/database_demo'));
        }
    }    
    public function destroy($id){
        chkaccess($this->data,$this->page,'delete');   
        $response = $this->dbdemomodel->destroy(base64_decode($id));
        $status = $response['status']===true?'success':'error';
        $this->session->set_flashdata($status, $response['message']);
        redirect(base_url('admin/database_demo'));
    }

    /**
     * 
     * Generate a unique url
    */
    public function keygen()
    {
        $chars = "abcdefghijklmnopqrstuvwxyz";
        $chars .= "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $chars .= "0123456789";
        while (1) {
            $key = '';
            srand((double) microtime() * 1000000);
            for ($i = 0; $i < 8; $i++) {
                $key .= substr($chars, (rand() % (strlen($chars))), 1);
            }
            break;
        }
        $checkip = array(
            '127.0.0.1',
            '::1'
        );

        if(in_array($_SERVER['REMOTE_ADDR'], $checkip)){
           return 'http://localhost/leadinexaldemo/demodb/'.$key.strtotime("now"); 
        }else{
            $livedemodburl = 'https://www.keraladatabasemarketing.in/database';
            return $livedemodburl.'/demodb/'.$key.strtotime("now"); 
        }
        
    }
}
