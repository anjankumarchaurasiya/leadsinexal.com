<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$config['googleplus']['application_name'] = 'Login_panel';
$config['googleplus']['client_id']        = '826412870409-oms46b8ea22hqji9butogargfe5l4gq9.apps.googleusercontent.com';
$config['googleplus']['client_secret']    = 'AKdHgiHIkKJqjk2H1-pgHQGb';
$config['googleplus']['redirect_uri']     = base_url().'googleauth';
$config['googleplus']['api_key']          = '';
$config['googleplus']['scopes']           = array();

